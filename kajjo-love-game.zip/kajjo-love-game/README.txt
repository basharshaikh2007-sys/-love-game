KAJJO LOVE GAME 💗

Your website is in index.html.

To publish free with GitHub Pages:
1. Sign in or create a free GitHub account.
2. Create a new public repository named kajjo-love-game.
3. Upload index.html from this folder to the repository's main page.
4. Open Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait a few minutes. GitHub will show your live website URL in Settings → Pages.

Before sharing, open the published link on your phone and test all answers.
The game is a static webpage and does not collect or send anyone's answers.
